<?php 

	$komputer = ["motherboard", "processor", "hard disk", "PC Coller", "VGA Card", "SSD"];

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>latihan 2</title>
</head>
<body>

	<h3>Macam-Macam perangkat keras komputer</h3>
		<ol>
			<?php foreach ($komputer as $k): ?>
		
	
			
				<li><?php echo $k ?></li>
			
			<?php endforeach ?>
		</ol>
	<h3>Macam-Macam perangkat keras komputer baru</h3>
		<?php   array_push($komputer, "Card Reader", "modem"); ?>
			<?php  sort($komputer); ?>
				<ol>
					<?php foreach ($komputer as $k): ?>
						<li><?php echo $k; ?></li>				
					<?php endforeach ?>
				</ol>
</body>
</html>