<?php 

$komponen = [
	[
		"barang" => "motherboard",
		"fungsi" => "papan sirkuit komponen komputer",
		"baru" => 50000,
		"seken" => 20000,
	],
	[
		"barang" => "Processor",
		"fungsi" => "sebuah ic yang mengontrol seluruh jalannya sistem komputer",
		"baru" => 300000,
		"seken" => 200000,
	],
	[
		"barang" => "Hard Disk",
		"fungsi" => "media penyimpanan sekunder",
		"baru" => 800000,
		"seken" => 500000,
	],
	[
		"barang" => "PC Coller",
		"fungsi" => "mengurangi panas yang dihasilkan oleh komputer",
		"baru" => 200000,
		"seken" => 100000,
	],
	[
		"barang" => "VGA Card",
		"fungsi" => "mengolah data grafik yang akan ditampilkan oleh monitor",
		"baru" => 900000,
		"seken" => 800000,
	],
	[
		"barang" => "Optical Drive",
		"fungsi" => "Membaca, maupun menulis data dari kepingan CD",
		"baru" => 500000,
		"seken" => 300000,
	],
	[
		"barang" => "Card Reader",
		"fungsi" => "untuk membaca data yang tersimpan didalam memory card",
		"baru" => 10000,
		"seken" => 5000,
	],
	[
		"barang" => "modem",
		"fungsi" => "mengubah sinyal digital menjadi sinyal analog",
		"baru" => 200000,
		"seken" => 150000,
	],
];

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Latihan 4D</title>
 </head>
 <style>
 	body{text-align: center;}

 	.left{text-align: left;}

 	table{border-collapse: collapse;}

 	.bold{font-weight: bold;}
 </style>
 <body>
 	<table border="1">
 		<tr class="bold">
 			<td>no</td>
 			<td>nama perangkat</td>
 			<td>fungsi</td>
 			<td>harga baru</td>
 			<td>harga second</td>
 		</tr>
 		<?php $i=1; ?>
 		<?php foreach ($komponen as $k): ?>
 			<tr>
 				<td><?php echo $i++ ?></td>
 				<td class="left"><?php echo $k["barang"] ?></td>
 				<td class="left"><?php echo $k["fungsi"] ?></td>
 				<td class="left">Rp<?php echo $k["baru"] ?></td>
 				<td class="left">Rp<?php echo $k["seken"] ?></td>
 			</tr>
 		<?php endforeach ?>

 		<?php $counter = 0; ?>
 			<tr>
 				<td>#</td>
 				<td colspan="2">Jumlah</td>
 				<td>Rp <?php foreach ($komponen as $k => $harga){$counter <= $harga["baru"];} echo $counter ?></td>
 				<td>Rp <?php foreach ($komponen as $k => $harga){$counter <= $harga["seken"];} echo $counter ?></td>
 			</tr>
 	</table>
 </body>
 </html>