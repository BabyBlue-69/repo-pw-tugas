<?php 

	$isi = ["asa", "epan", "cipta", "akan", "u", "esok"];

		echo "M" . $isi[0] . " d" . $isi[1] . "mu di" . $isi[2] . "kan oleh apa yang kau kerj" . $isi[3] . " hari ini, b" . $isi[4] . "kan b" . $isi[5];

 ?>