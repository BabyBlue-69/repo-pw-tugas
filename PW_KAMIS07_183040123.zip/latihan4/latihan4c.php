<?php 

	$komputer = [
		"motherboard" => "Papan Sirkuit komponen komputer",
		"processor" => "Sebuah IC yang mengontrol seluruh jalannya sistem komputer",
		"hard disk" => "Media penyimpanan sekunder",
		"PC Coller" => "Mengurangi panas yang dihasilkan oleh komputer",
		"VGA Card" => "Mengolah data grafik yang akan ditampilkan oleh monitor",
		"Optical Drive" => "Membaca, maupun menulis data dari kepingan CD",
		"Card Reader" => "Untuk membaca data-data yang tersimpan didalam memory card",
		"Modem" => "Mengubah sinyal digital menjadi sinyal analog"];

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Latihan 4c</title>
 </head>
 <body>
 
 	<h3>macam-macam perangkat keras komputer dan fungsinya</h3>
 		<table border="0">
 			<?php foreach ($komputer as $k => $fungsi ) : ?>
 				<tr>
 					<td><?php echo $k; ?></td>
 					<td><?php echo ":" ?></td>
 					<td><?php echo $fungsi; ?></td>
 				</tr>
 			<?php endforeach ?>
 		</table>
 		
 	


 </body>
 </html>