<!DOCTYPE html>
<html>
<head>
	<title>Index php</title>
	<style>
		.link{
			color: black;
		}
	</style>
</head>
<body bgcolor="cyan">
		<h1 align="center">Index Tugas Praktikum</h1>
		<h1 align="center">Pemrograman Web</h1>
		<h2 align="center">Muhammad Daffa Firdaus</h2>
		<h2 align="center">183040123</h2>
	<?php 
	echo"<div class='link'>
		<h1>Daftar Link</h1>

		<h2>Pertemuan3</h2>
			<h3><li><a href='latihan3/latihan3a.php'>Latihan3a</a></li></h3>
			<h3><li><a href='latihan3/latihan3b.php'>Latihan3b</a></li></h3>
			<h3><li><a href='latihan3/latihan3c.php'>Latihan3c</a></li></h3>
			<h3><li><a href='latihan3/latihan3d.php'>Latihan3d</a></li></h3>
		<h2>Pertemuan4</h2>
			<h3><li><a href='latihan4/latihan4a.php'>Latihan4a</a></li></h3>
			<h3><li><a href='latihan4/latihan4b.php'>Latihan4b</a></li></h3>
			<h3><li><a href='latihan4/latihan4c.php'>Latihan4c</a></li></h3>
			<h3><li><a href='latihan4/latihan4d.php'>Latihan4d</a></li></h3>
			

		</div>

	</div>";
	 ?>
</body>
</html>
