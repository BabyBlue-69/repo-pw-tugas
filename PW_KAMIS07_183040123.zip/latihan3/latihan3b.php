<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Latihan3b_183040127</title>
        <style>
            .kotak {
                border: 1px solid black;
                padding: 10px;
            }
        </style>
    </head>
    <body>
        <?php
            $GLOBALS['jawabanIsset'] = "Isset() : Fungsi isset pada PHP ini akan mengembalikan sebuah nilai boolean (false) jika variabel yang kita cek tidak memiliki nilai, atau nilainya NULL. <br><br>";
            $GLOBALS['jawabanEmpty'] = "Empty() : Dilakukan untuk melakukan pemeriksaan apakan suatu variabel sudah terisi atau belum.";
            function soal($style){
                echo "<div class='$style'>" . $GLOBALS['jawabanIsset'] . $GLOBALS['jawabanEmpty'] . "</div>";
            }
            soal("kotak");
        ?>
    </body>
</html>