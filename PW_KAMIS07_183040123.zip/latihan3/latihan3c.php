<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Latihan3c_183040127</title>
    </head>
    <body>
        <?php
            function hitungLuasLingkaran($r) {
                echo "<h1>Menghitung Luas Lingkaran</h1>";
                echo "Jari-jari = $r";
                echo "<br>";
                echo "Luas lingkaran = " . round(pi() * pow($r, 2)) . " cm²";
                echo "<hr>";
                // round() <-- Pembulatan nilai Desimal
                // pi() <-- Nilai pi (bawaan PHP, 3.14/ 22/7)
                // pow() <-- fungsi pemangkatan (butuh 2 parameter)
            }
            function hitungKelilingLingkaran($r) {
                echo "<h1>Menghitung Keliling Lingkaran</h1>";
                echo "Jari-jari = $r";
                echo "<br>";
                echo "Keliling lingkaran = " . round(pi() * (2 * $r), 1) . " cm";
                echo "<hr>";
            }
            
            hitungLuasLingkaran(20);
            hitungKelilingLingkaran(30);
        ?>
	</body>
</html>